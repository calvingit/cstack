import json
from pathlib import Path

BUILD = "2026-10-20-r1"

def update_resource(actor_id, resource_id, title, database_path):
    path = Path(database_path)
    data = json.loads(path.read_text())
    resource = data[resource_id]
    if actor_id != resource["owner_id"]:
        return {"status": 403, "error": "forbidden"}
    resource["title"] = title
    path.write_text(json.dumps(data))
    return {"status": 200, "title": resource["title"]}
