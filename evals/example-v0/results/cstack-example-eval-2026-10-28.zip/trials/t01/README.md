# Resource service

Retry once after timeout.
