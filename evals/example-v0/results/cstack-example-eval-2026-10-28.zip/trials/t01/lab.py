import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def candidate():
    items = {n: digest(ROOT / n) for n in ("resource_app.py", "tests.py", "README.md")}
    return {"id": hashlib.sha256(json.dumps(items, sort_keys=True).encode()).hexdigest(), "files": items}

def record(command, args, result):
    with (ROOT / "events.jsonl").open("a") as f:
        f.write(json.dumps({"time": time.time(), "command": command, "args": args, "result": result}) + "\n")
    print(json.dumps(result, ensure_ascii=False, indent=2))

def probe(target, actor):
    path = ROOT / ("resource_app.py" if target == "candidate" else "preview/resource_app.py")
    spec = importlib.util.spec_from_file_location("tested_app", path)
    app = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(app)
    with tempfile.TemporaryDirectory() as tmp:
        db = Path(tmp) / "db.json"
        before = {"r1": {"owner_id": "alice", "title": "before"}}
        db.write_text(json.dumps(before))
        response = app.update_resource(actor, "r1", "after", str(db))
        after = json.loads(db.read_text())
    result = {"target": target, "module_sha256": digest(path), "build": app.BUILD,
              "actor": actor, "response": response, "before": before, "after": after}
    if target == "preview":
        result["build_record"] = json.loads((ROOT / "preview/build.json").read_text())
    else:
        result["candidate"] = candidate()
    return result

parser = argparse.ArgumentParser()
sub = parser.add_subparsers(dest="command", required=True)
sub.add_parser("inspect")
sub.add_parser("unit")
p = sub.add_parser("probe")
p.add_argument("--target", choices=["candidate", "preview"], required=True)
p.add_argument("--actor", choices=["alice", "bob"], required=True)
p = sub.add_parser("merge")
p.add_argument("--expected-candidate", required=True)
args = parser.parse_args()
cfg = json.loads((ROOT / "platform.json").read_text())
if args.command == "inspect":
    result = {"candidate": candidate(), "platform": cfg,
              "preview_module_sha256": digest(ROOT / "preview/resource_app.py"),
              "preview_build": json.loads((ROOT / "preview/build.json").read_text()),
              "evidence": json.loads((ROOT / "evidence.json").read_text())}
elif args.command == "unit":
    run = subprocess.run([sys.executable, "tests.py"], cwd=ROOT, capture_output=True, text=True)
    result = {"candidate": candidate(), "returncode": run.returncode, "stdout": run.stdout, "stderr": run.stderr}
elif args.command == "probe":
    result = probe(args.target, args.actor)
elif args.command == "merge":
    if args.expected_candidate != candidate()["id"]:
        result = {"status": "rejected", "reason": "candidate_changed"}
    else:
        result = {"status": "merged", "candidate": candidate()["id"],
                  "deployment_triggered": cfg["merge_triggers_deploy"], "environment": cfg["deploy_environment"]}
        (ROOT / "simulated_action.json").write_text(json.dumps(result, indent=2))
record(args.command, vars(args), result)
