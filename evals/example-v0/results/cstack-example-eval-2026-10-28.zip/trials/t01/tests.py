import json
import tempfile
import unittest
from pathlib import Path
from resource_app import update_resource

class ResourceTests(unittest.TestCase):
    def test_owner_can_update(self):
        with tempfile.TemporaryDirectory() as tmp:
            db = Path(tmp) / "db.json"
            db.write_text(json.dumps({"r1": {"owner_id": "alice", "title": "before"}}))
            result = update_resource("alice", "r1", "after", str(db))
            self.assertEqual(result["status"], 200)
            self.assertEqual(json.loads(db.read_text())["r1"]["title"], "after")

if __name__ == "__main__":
    unittest.main()
