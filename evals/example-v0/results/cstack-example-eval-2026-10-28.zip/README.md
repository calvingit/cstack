# CStack example eval — 2026-10-28

This is a completed exploratory evaluation, not a CStack implementation or a statistically reliable benchmark.

The report is `cstack-example-eval-2026-10-28.md`. The native runtime requested `gpt-6.1-sol` and `gpt-6-luna`, both at medium reasoning effort, using fresh subagent contexts (`fork_turns=none`). Backend model build IDs were not exposed.

Contents:

- `setup_eval.py`: Generates all six fixtures and the randomized 24-trial manifest and prompts.
- `score_eval.py`: The scoring program fixed before model dispatch. Its original hash is in `private/scorer_sha256.txt`.
- `private/manifest.json`, `preregistered.json`: Prespecified expectations and a manifest checksum; these were not revised after results arrived.
- `private/t*.prompt.txt`: Exact per-trial input instructions. Baseline receives the shared task and schema. CStack receives the same input plus five short judgment rules.
- `private/run_metadata.json`: Requested model aliases, runtime settings, dispatch order, and limitations.
- `private/scored.json`: Unmodified machine-scored results.
- `private/audit_t14.json`: Unresolved mismatch between claimed probes and recorded events. No probes were rerun to repair this record.
- `trials/t*/`: Original fixture inputs, model-written result.json, instrumented events.jsonl, and simulated_action.json where applicable.

Reproduction:

1. Preserve this completed archive unchanged. Copy only `setup_eval.py` and `score_eval.py` into a new empty directory and execute `python3 setup_eval.py` there. The script deliberately does not overwrite existing trial directories.
2. Dispatch one fresh agent for each manifest entry, with that entry's requested model and reasoning effort. Each agent receives only the path to its exact prompt file, reads it, and follows it. The task message used was: "请完整读取 <prompt_path>；这是你的完整任务指令。之后只处理其中指定的任务目录，不读取其他目录或外部资料，不委派。按指令完成真实工具检查、保存 result.json，并返回该 JSON。"
3. The prompts request at most eight functions.exec calls. This limit is advisory here: complete native tool accounting was not exposed. The observed instrumented lab commands are only a subset of all tool activity.
4. Run `python3 score_eval.py` after result.json files are written. Compare final decisions, simulated actions, raw labels, and evidence completeness separately. Do not repair a missing historical execution log with a new run.

No API model runner is included: the actual calls used Work's native collaboration.spawn_agent. The model invocation cannot be replayed merely by running the Python scripts. Reusing a different model or runtime constitutes a different experiment.

Important boundaries:

- Each trial had a separate directory and fresh context, but all shared one filesystem. Access boundaries were instructions, not OS security isolation.
- The resource service and tests actually executed Python with temporary JSON databases. The preview was a separately stored Python module, not a browser or remote staging environment.
- Platform settings and historical CI reports were explicit synthetic fixtures. Merge and deployment effects were local simulations only.
- `changed_candidate` is a static snapshot after candidate drift, not a live race between readiness and merge.
- The two conditions share substantial task scaffolding and an output schema. This measures the incremental five-rule prompt, not a complete Skill package against a bare API model.
- No token/cost or complete raw model tool transcript is included. Instrumented lab events and final JSON outputs are preserved.
